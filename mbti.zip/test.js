const { Pool } = require('pg');


let personList = [];

const pg=new Pool ({
    user:'postgres',
    host:'localhost',
    database:'mbti',
    password:'hp75841587f*',
    port:5432
});
pg.connect(err =>{
    if(err) console.log(err);
    else{
        console.log("Database Connected Successfully.")
    }
});

/*
pg.query('SELECT * FROM main', (err, rows) => {
    if (!err) console.log(rows);
    else console.log(err);
});
 */

/*
function getPersonList(callback)
{

}

getPersonList()


function callbackFunc(callback) {
    pg.query('SELECT * FROM main', (err, rows) => {
        if (!err) var data = rows[0];
        else console.log(err);
        callback(data);
    });
}

function show(data) {
    return data;
}

var neu = callbackFunc(show)

console.log(typeof(neu));
*/
let posts = []

pg.query('SELECT * FROM main', (err, res) => {
    posts = res
    pg.end();
})

console.log(posts)