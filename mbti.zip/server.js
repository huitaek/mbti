// express 모듈 불러오기
const express = require('express');

// handlebars 모듈 불러오기

// express app 인스턴스에 담기
const app = express();

// 포트 번호 상수
const PORT = 80;

app.listen(PORT, ()=>{
    console.log(`포트 번호 ${PORT} 서버접속`)
})

app.use(express.urlencoded({extended: true}))
// IF extended: true, 객체 형태로 전달된 데이터내에서 또다른 중첩된 객체를 허용한다
// IF extended: false, 객체 형태로 전달된 데이터내에서 또다른 중첩된 객체를 허용하지 않는다

// template engine 미들웨어 셋업 : express-handlebars
app.set('view engine', 'ejs')


// DB Connect
const { Pool } = require('pg');
const pg=new Pool ({
    user:'postgres',
    host:'localhost',
    database:'mbti',
    password:'hp75841587f*',
    port:5432
});

app.get('/', (req, res)=>{
    res.sendFile(__dirname +'/index.html')
});

app.get('/input', (req, res)=>{
    res.sendFile(__dirname +'/input.html')
});

app.get('/view', (req, res)=>{
    var rows = 'testsdfsdf'
    res.sendFile(__dirname +'/view.html')
});

app.get('/test', (req, res)=>{
    res.sendFile(__dirname +'/test.html')
});

app.post('/add', (req, res)=>{

    pg.connect(err =>{
        if(err) console.log(err);
        else{
            console.log("Database Connected Successfully.")
        }
    });

    var data = req.body;

    var today = new Date();
    data.firstDate = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();
    data.recentDate = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();

    const queryString = `INSERT INTO main(name, position, mbti, recent_date, first_date)
    VALUES('${data.name}', '${data.position}', '${data.mbti}', '${data.recentDate}',
        (CASE (SELECT EXISTS (SELECT id FROM main WHERE name = '${data.name}' ORDER BY recent_date LIMIT 1) AS existence)
            WHEN true THEN (SELECT first_date FROM main WHERE name = '${data.name}' LIMIT 1)  
            WHEN false THEN '${data.recentDate}'   
        END))`;
/*
    queryString = `INSERT INTO main VALUES (DEFAULT, '${data.name}', '${data.position}', '${data.mbti}', '2022-07-27', '2022-07-27')`
*/
    pg.query(queryString, (err, res) => {
        if (!err) console.log(res);
        else console.log(err);
    });

    res.send('전송완료');
});

